Modern CV Template Pack (sample)
=================================

This is a placeholder for the real product. Replace the contents of this
zip with your actual 5 CV template files (Word/PDF) before going live —
the store only cares that a file with this exact name exists in
data/downloads/.
